"""Ứng dụng quản lý công việc nhỏ dùng để thực hành Python venv."""

import json
from pathlib import Path

try:
    from colorama import Fore, Style, init

    init(autoreset=True)
except ImportError:
    class _NoColor:
        def __getattr__(self, _name):
            return ""

    Fore = Style = _NoColor()


DATA_FILE = Path(__file__).with_name("tasks.json")


def load_tasks():
    if not DATA_FILE.exists():
        return []
    try:
        return json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        print(Fore.YELLOW + "Không đọc được tasks.json. Dùng danh sách rỗng.")
        return []


def save_tasks(tasks):
    DATA_FILE.write_text(
        json.dumps(tasks, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def show_tasks(tasks):
    print("\nDANH SÁCH CÔNG VIỆC")
    if not tasks:
        print("Chưa có công việc nào.")
        return
    for index, task in enumerate(tasks, start=1):
        mark = "✓" if task["done"] else " "
        color = Fore.GREEN if task["done"] else Fore.CYAN
        print(color + f"{index}. [{mark}] {task['title']}")


def add_task(tasks):
    title = input("Nhập nội dung công việc: ").strip()
    if not title:
        print(Fore.YELLOW + "Nội dung không được để trống.")
        return
    tasks.append({"title": title, "done": False})
    save_tasks(tasks)
    print(Fore.GREEN + "Đã thêm công việc.")


def choose_task(tasks, action):
    show_tasks(tasks)
    if not tasks:
        return
    try:
        number = int(input(f"Nhập số thứ tự cần {action}: "))
        if not 1 <= number <= len(tasks):
            raise ValueError
    except ValueError:
        print(Fore.RED + "Số thứ tự không hợp lệ.")
        return

    if action == "hoàn thành":
        tasks[number - 1]["done"] = True
        message = "Đã đánh dấu hoàn thành."
    else:
        removed = tasks.pop(number - 1)
        message = f"Đã xóa: {removed['title']}"
    save_tasks(tasks)
    print(Fore.GREEN + message)


def main():
    tasks = load_tasks()
    while True:
        print("\n=== MINI TASK MANAGER ===")
        print("1. Xem công việc")
        print("2. Thêm công việc")
        print("3. Đánh dấu hoàn thành")
        print("4. Xóa công việc")
        print("0. Thoát")
        choice = input("Chọn chức năng: ").strip()

        if choice == "1":
            show_tasks(tasks)
        elif choice == "2":
            add_task(tasks)
        elif choice == "3":
            choose_task(tasks, "hoàn thành")
        elif choice == "4":
            choose_task(tasks, "xóa")
        elif choice == "0":
            print("Hẹn gặp lại!")
            break
        else:
            print(Fore.RED + "Vui lòng chọn từ 0 đến 4.")


if __name__ == "__main__":
    main()
