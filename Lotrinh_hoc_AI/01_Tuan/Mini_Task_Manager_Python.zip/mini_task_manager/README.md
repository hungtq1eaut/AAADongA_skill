# Mini Task Manager

Dự án Python nhỏ để thực hành tạo và sử dụng môi trường ảo `venv`.

## Chạy nhanh trên Windows CMD

```bat
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

Gõ `deactivate` để thoát môi trường ảo.
